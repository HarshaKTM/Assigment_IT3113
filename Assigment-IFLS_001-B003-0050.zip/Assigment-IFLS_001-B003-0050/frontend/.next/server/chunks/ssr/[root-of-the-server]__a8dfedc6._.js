module.exports = {

"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}}),
"[externals]/util [external] (util, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}}),
"[externals]/stream [external] (stream, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}}),
"[externals]/path [external] (path, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}}),
"[externals]/http [external] (http, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}}),
"[externals]/https [external] (https, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}}),
"[externals]/url [external] (url, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}}),
"[externals]/fs [external] (fs, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}}),
"[externals]/crypto [external] (crypto, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}}),
"[externals]/assert [external] (assert, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}}),
"[externals]/tty [external] (tty, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}}),
"[externals]/os [external] (os, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}}),
"[externals]/zlib [external] (zlib, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}}),
"[externals]/events [external] (events, cjs)": (function(__turbopack_context__) {

var { g: global, __dirname, m: module, e: exports } = __turbopack_context__;
{
const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}}),
"[project]/app/services/api.ts [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "authAPI": (()=>authAPI),
    "booksAPI": (()=>booksAPI),
    "cartAPI": (()=>cartAPI),
    "default": (()=>__TURBOPACK__default__export__),
    "ordersAPI": (()=>ordersAPI)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-ssr] (ecmascript)");
;
const API_URL = process.env.NEXT_PUBLIC_API_URL || 'http://localhost:5000/api';
const GOOGLE_BOOKS_API_URL = 'https://www.googleapis.com/books/v1/volumes';
const GOOGLE_BOOKS_API_KEY = process.env.NEXT_PUBLIC_GOOGLE_BOOKS_API_KEY || 'AIzaSyBtOn5PsETljURB5nKAVVEVOJm_ufcPcBY';
// Create axios instance with base URL
const api = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: API_URL,
    headers: {
        'Content-Type': 'application/json'
    }
});
// Create a separate axios instance for Google Books API
const googleBooksApi = __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].create({
    baseURL: GOOGLE_BOOKS_API_URL,
    headers: {
        'Content-Type': 'application/json'
    }
});
// Improve request interceptor to include auth token and handle development mode
api.interceptors.request.use((config)=>{
    let token;
    if ("TURBOPACK compile-time falsy", 0) {
        "TURBOPACK unreachable";
    }
    if (token) {
        config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
}, (error)=>Promise.reject(error));
// Add response interceptor for auto-login in development mode
api.interceptors.response.use((response)=>response, (error)=>{
    // If we get 401 in development mode, try to auto-login
    if (error.response?.status === 401 && ("TURBOPACK compile-time value", "development") === 'development') {
        console.log('401 error in development mode, using mock authentication');
        // Store mock user and token in localStorage
        if ("TURBOPACK compile-time falsy", 0) {
            "TURBOPACK unreachable";
        }
    }
    return Promise.reject(error);
});
const authAPI = {
    register: async (userData)=>{
        try {
            const response = await api.post('/auth/register', userData);
            return response.data;
        } catch (error) {
            console.error('Registration error:', error);
            throw error;
        }
    },
    login: async (credentials)=>{
        try {
            const response = await api.post('/auth/login', credentials);
            return response.data;
        } catch (error) {
            console.error('Login error:', error);
            // For demo purposes, simulate successful login if backend is not available
            if ("TURBOPACK compile-time truthy", 1) {
                console.warn('Using mock login for development');
                return {
                    token: 'mock-token-for-development',
                    user: {
                        _id: '123',
                        username: credentials.email.split('@')[0],
                        email: credentials.email,
                        role: 'user'
                    }
                };
            }
            "TURBOPACK unreachable";
        }
    },
    getCurrentUser: async ()=>{
        try {
            const response = await api.get('/auth/me');
            return response.data;
        } catch (error) {
            console.error('Error getting current user:', error);
            // For demo mode
            if ("TURBOPACK compile-time falsy", 0) {
                "TURBOPACK unreachable";
            }
            throw error;
        }
    },
    logout: async ()=>{
        try {
            if ("TURBOPACK compile-time falsy", 0) {
                "TURBOPACK unreachable";
            }
            return {
                success: true
            };
        } catch (error) {
            console.error('Logout error:', error);
            throw error;
        }
    }
};
const booksAPI = {
    getBooks: async (page = 1, limit = 10, search = '')=>{
        try {
            const response = await api.get('/books', {
                params: {
                    page,
                    limit,
                    search
                }
            });
            return response.data;
        } catch (error) {
            console.error('Error fetching books:', error);
            return {
                books: [],
                totalPages: 0,
                currentPage: 1,
                total: 0
            };
        }
    },
    getBook: async (id)=>{
        try {
            const response = await api.get(`/books/${id}`);
            return response.data;
        } catch (error) {
            console.error('Error fetching book details:', error);
            throw error;
        }
    },
    searchGoogleBooks: async (query, startIndex = 0, maxResults = 10, filter = '')=>{
        try {
            // Try to use the backend endpoint first
            try {
                const response = await api.get('/books/google/search', {
                    params: {
                        q: query,
                        startIndex,
                        maxResults,
                        filter
                    }
                });
                return response.data;
            } catch (backendError) {
                console.warn('Failed to fetch from backend, using Google Books API directly', backendError);
                // If backend fails, use Google Books API directly
                const response = await googleBooksApi.get('', {
                    params: {
                        q: query,
                        startIndex,
                        maxResults,
                        filter,
                        key: GOOGLE_BOOKS_API_KEY
                    }
                });
                return {
                    books: response.data.items || [],
                    totalItems: response.data.totalItems || 0
                };
            }
        } catch (error) {
            console.error('Error searching Google Books:', error);
            return {
                books: [],
                totalItems: 0
            };
        }
    },
    importBook: async (googleBookId, data)=>{
        try {
            const response = await api.post(`/books/import/${googleBookId}`, data);
            return response.data;
        } catch (error) {
            console.error('Error importing book:', error);
            // For development mode, create a mock imported book
            if ("TURBOPACK compile-time truthy", 1) {
                console.log('Using mock book import for development');
                return {
                    _id: `dev_${googleBookId}`,
                    ...data,
                    createdAt: new Date().toISOString(),
                    updatedAt: new Date().toISOString()
                };
            }
            "TURBOPACK unreachable";
        }
    },
    updateBook: async (id, data)=>{
        try {
            const response = await api.put(`/books/${id}`, data);
            return response.data;
        } catch (error) {
            console.error('Error updating book:', error);
            throw error;
        }
    },
    deleteBook: async (id)=>{
        try {
            const response = await api.delete(`/books/${id}`);
            return response.data;
        } catch (error) {
            console.error('Error deleting book:', error);
            throw error;
        }
    }
};
const cartAPI = {
    getCart: async ()=>{
        try {
            const response = await api.get('/cart');
            return response.data;
        } catch (error) {
            console.error('Error fetching cart:', error);
            // Development mode fallback
            if ("TURBOPACK compile-time truthy", 1) {
                console.log('Using mock cart data in development mode');
                // Get cart from localStorage or initialize empty
                const localCart = localStorage.getItem('dev_cart');
                const cart = localCart ? JSON.parse(localCart) : {
                    items: [],
                    totalAmount: 0
                };
                return {
                    cart
                };
            }
            "TURBOPACK unreachable";
        }
    },
    addToCart: async (bookId, quantity = 1)=>{
        try {
            const response = await api.post('/cart/add', {
                bookId,
                quantity
            });
            return response.data;
        } catch (error) {
            console.error('Error adding to cart:', error);
            // Development mode fallback
            if ("TURBOPACK compile-time truthy", 1) {
                console.log('Using local cart in development mode for adding item');
                // Get cart from localStorage or initialize empty
                const localCart = localStorage.getItem('dev_cart');
                const cart = localCart ? JSON.parse(localCart) : {
                    items: [],
                    totalAmount: 0
                };
                // Create a mock item
                const newItem = {
                    _id: `local_${Date.now()}`,
                    bookId,
                    title: 'Book Title',
                    authors: [
                        'Author'
                    ],
                    price: 9.99,
                    quantity,
                    imageUrl: 'https://via.placeholder.com/150'
                };
                // Add to cart
                cart.items.push(newItem);
                cart.totalAmount = cart.items.reduce((total, item)=>total + item.price * item.quantity, 0);
                // Save to localStorage
                localStorage.setItem('dev_cart', JSON.stringify(cart));
                return {
                    success: true,
                    cart
                };
            }
            "TURBOPACK unreachable";
        }
    },
    updateCartItem: async (itemId, quantity)=>{
        try {
            const response = await api.put(`/cart/update/${itemId}`, {
                quantity
            });
            return response.data;
        } catch (error) {
            console.error('Error updating cart item:', error);
            // Development mode fallback
            if ("TURBOPACK compile-time truthy", 1) {
                console.log('Using local cart in development mode for updating item');
                // Get cart from localStorage
                const localCart = localStorage.getItem('dev_cart');
                if (!localCart) {
                    return {
                        cart: {
                            items: [],
                            totalAmount: 0
                        }
                    };
                }
                const cart = JSON.parse(localCart);
                // Find and update item
                const itemIndex = cart.items.findIndex((item)=>item._id === itemId);
                if (itemIndex !== -1) {
                    cart.items[itemIndex].quantity = quantity;
                    cart.totalAmount = cart.items.reduce((total, item)=>total + item.price * item.quantity, 0);
                    // Save to localStorage
                    localStorage.setItem('dev_cart', JSON.stringify(cart));
                }
                return {
                    success: true,
                    cart
                };
            }
            "TURBOPACK unreachable";
        }
    },
    removeFromCart: async (itemId)=>{
        try {
            const response = await api.delete(`/cart/remove/${itemId}`);
            return response.data;
        } catch (error) {
            console.error('Error removing from cart:', error);
            // Development mode fallback
            if ("TURBOPACK compile-time truthy", 1) {
                console.log('Using local cart in development mode for removing item');
                // Get cart from localStorage
                const localCart = localStorage.getItem('dev_cart');
                if (!localCart) {
                    return {
                        cart: {
                            items: [],
                            totalAmount: 0
                        }
                    };
                }
                const cart = JSON.parse(localCart);
                // Remove item
                cart.items = cart.items.filter((item)=>item._id !== itemId);
                cart.totalAmount = cart.items.reduce((total, item)=>total + item.price * item.quantity, 0);
                // Save to localStorage
                localStorage.setItem('dev_cart', JSON.stringify(cart));
                return {
                    success: true,
                    cart
                };
            }
            "TURBOPACK unreachable";
        }
    },
    clearCart: async ()=>{
        try {
            const response = await api.delete('/cart/clear');
            return response.data;
        } catch (error) {
            console.error('Error clearing cart:', error);
            // Development mode fallback
            if ("TURBOPACK compile-time truthy", 1) {
                console.log('Using local cart in development mode for clearing cart');
                // Clear cart in localStorage
                localStorage.setItem('dev_cart', JSON.stringify({
                    items: [],
                    totalAmount: 0
                }));
                return {
                    success: true,
                    cart: {
                        items: [],
                        totalAmount: 0
                    }
                };
            }
            "TURBOPACK unreachable";
        }
    }
};
const ordersAPI = {
    async checkout (orderData) {
        try {
            const response = await api.post('/orders/checkout', orderData);
            return response.data;
        } catch (error) {
            if ("TURBOPACK compile-time truthy", 1) {
                console.log('Using mock order in development mode');
                // Mock successful checkout in development
                return {
                    success: true,
                    order: {
                        _id: `order-${Date.now()}`,
                        ...orderData,
                        status: 'processing',
                        createdAt: new Date().toISOString()
                    }
                };
            }
            "TURBOPACK unreachable";
        }
    },
    async getUserOrders () {
        try {
            const response = await api.get('/orders');
            return response.data;
        } catch (error) {
            if ("TURBOPACK compile-time truthy", 1) {
                console.log('Using mock orders in development mode');
                // Return empty orders array in development
                return {
                    orders: []
                };
            }
            "TURBOPACK unreachable";
        }
    },
    async getOrderById (orderId) {
        try {
            const response = await api.get(`/orders/${orderId}`);
            return response.data;
        } catch (error) {
            if ("TURBOPACK compile-time truthy", 1) {
                console.log('Using mock order in development mode');
                // Return mock order in development
                return {
                    order: null
                };
            }
            "TURBOPACK unreachable";
        }
    },
    async updatePayment (orderId, paymentData) {
        try {
            const response = await api.put(`/orders/${orderId}/payment`, paymentData);
            return response.data;
        } catch (error) {
            if ("TURBOPACK compile-time truthy", 1) {
                console.log('Using mock payment update in development mode');
                // Mock successful payment update in development
                return {
                    success: true,
                    order: {
                        _id: orderId,
                        payment: {
                            ...paymentData,
                            updatedAt: new Date().toISOString()
                        }
                    }
                };
            }
            "TURBOPACK unreachable";
        }
    },
    // Admin only
    getAllOrders: async (page = 1, limit = 10)=>{
        try {
            const response = await api.get('/orders/admin/all', {
                params: {
                    page,
                    limit
                }
            });
            return response.data;
        } catch (error) {
            console.error('Error fetching all orders:', error);
            return {
                orders: [],
                totalPages: 0,
                currentPage: 1,
                total: 0
            };
        }
    },
    updateOrderStatus: async (id, status)=>{
        try {
            const response = await api.put(`/orders/${id}/status`, {
                status
            });
            return response.data;
        } catch (error) {
            console.error('Error updating order status:', error);
            throw error;
        }
    }
};
const __TURBOPACK__default__export__ = api;
}}),
"[project]/app/context/AuthContext.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "AuthProvider": (()=>AuthProvider),
    "useAuth": (()=>useAuth)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/services/api.ts [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/react-hot-toast/dist/index.mjs [app-ssr] (ecmascript)");
'use client';
;
;
;
;
const AuthContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(undefined);
const AuthProvider = ({ children })=>{
    const [user, setUser] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(true);
    const [error, setError] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(null);
    const [isInitialized, setIsInitialized] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    // Check for token on first load
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const initializeAuth = async ()=>{
            try {
                const token = localStorage.getItem('token');
                if (token) {
                    // In development mode, always consider the token valid
                    if ("TURBOPACK compile-time truthy", 1) {
                        // Get user data from localStorage or create mock user
                        const userData = localStorage.getItem('user');
                        if (userData) {
                            setUser(JSON.parse(userData));
                        } else {
                            // Create a mock user for development
                            const mockUser = {
                                _id: 'mock-user-id',
                                username: 'mockuser',
                                email: 'mock@example.com',
                                role: 'user'
                            };
                            localStorage.setItem('user', JSON.stringify(mockUser));
                            setUser(mockUser);
                        }
                    } else {
                        "TURBOPACK unreachable";
                    }
                }
            } catch (error) {
                console.error('Auth initialization error:', error);
            } finally{
                setLoading(false);
                setIsInitialized(true);
            }
        };
        initializeAuth();
    }, []);
    const login = async (email, password)=>{
        setLoading(true);
        setError(null);
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["authAPI"].login({
                email,
                password
            });
            // Save token and user to local storage
            localStorage.setItem('token', response.token);
            localStorage.setItem('user', JSON.stringify(response.user));
            setUser(response.user);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].success('Login successful');
        } catch (error) {
            const errorMessage = error.response?.data?.message || 'Login failed';
            setError(errorMessage);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].error(errorMessage);
            throw error;
        } finally{
            setLoading(false);
        }
    };
    const register = async (userData)=>{
        setLoading(true);
        setError(null);
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["authAPI"].register(userData);
            // Save token and user to local storage
            localStorage.setItem('token', response.token);
            localStorage.setItem('user', JSON.stringify(response.user));
            setUser(response.user);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].success('Registration successful');
        } catch (error) {
            const errorMessage = error.response?.data?.message || 'Registration failed';
            setError(errorMessage);
            __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].error(errorMessage);
            throw error;
        } finally{
            setLoading(false);
        }
    };
    const logout = async ()=>{
        if (window.confirm('Are you sure you want to log out?')) {
            setLoading(true);
            try {
                await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["authAPI"].logout();
                setUser(null);
                localStorage.removeItem('token');
                localStorage.removeItem('user');
                __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$react$2d$hot$2d$toast$2f$dist$2f$index$2e$mjs__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["default"].success('Logged out successfully');
            } catch (error) {
                console.error('Logout error:', error);
            } finally{
                setLoading(false);
            }
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(AuthContext.Provider, {
        value: {
            user,
            loading: loading && !isInitialized,
            error,
            isAuthenticated: !!user,
            login,
            register,
            logout
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/app/context/AuthContext.tsx",
        lineNumber: 151,
        columnNumber: 5
    }, this);
};
const useAuth = ()=>{
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(AuthContext);
    if (context === undefined) {
        throw new Error('useAuth must be used within an AuthProvider');
    }
    return context;
};
}}),
"[project]/app/context/CartContext.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "CartProvider": (()=>CartProvider),
    "useCart": (()=>useCart)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/services/api.ts [app-ssr] (ecmascript)");
'use client';
;
;
;
// Create context
const CartContext = /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["createContext"])(undefined);
function CartProvider({ children }) {
    const [cart, setCart] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])([]);
    const [totalItems, setTotalItems] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [totalAmount, setTotalAmount] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(0);
    const [loading, setLoading] = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useState"])(false);
    // Initialize cart from API
    (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useEffect"])(()=>{
        const fetchCart = async ()=>{
            try {
                const data = await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cartAPI"].getCart();
                setCart(data.cart.items || []);
                calculateTotals(data.cart.items || []);
            } catch (error) {
                console.error('Error fetching cart:', error);
                // Initialize empty cart on error
                setCart([]);
                setTotalItems(0);
                setTotalAmount(0);
            }
        };
        // Get token from localStorage
        const token = ("TURBOPACK compile-time falsy", 0) ? ("TURBOPACK unreachable", undefined) : null;
        // Only fetch cart if user is authenticated (token exists)
        if ("TURBOPACK compile-time falsy", 0) {
            "TURBOPACK unreachable";
        } else {
            // Clear cart if not authenticated
            setCart([]);
            setTotalItems(0);
            setTotalAmount(0);
        }
    }, []);
    // Calculate cart totals
    const calculateTotals = (items)=>{
        const itemCount = items.reduce((total, item)=>total + item.quantity, 0);
        const amount = items.reduce((total, item)=>total + item.price * item.quantity, 0);
        setTotalItems(itemCount);
        setTotalAmount(amount);
    };
    // Add a function to refresh cart after operations
    const refreshCart = async ()=>{
        try {
            const data = await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cartAPI"].getCart();
            setCart(data.cart.items || []);
            calculateTotals(data.cart.items || []);
            return data;
        } catch (error) {
            console.error('Error refreshing cart:', error);
            return null;
        }
    };
    // Add an item to the cart
    const addToCart = async (bookId, quantity)=>{
        setLoading(true);
        try {
            console.log(`Adding book to cart: ${bookId} with quantity: ${quantity}`);
            const data = await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cartAPI"].addToCart(bookId, quantity);
            // Update state with the response data
            if (data && data.cart && data.cart.items) {
                setCart(data.cart.items);
                calculateTotals(data.cart.items);
            } else if ("TURBOPACK compile-time truthy", 1) {
                // In case the data structure is different in development mode
                await refreshCart();
            }
            console.log('Book added to cart successfully');
            return data;
        } catch (error) {
            console.error('Error adding item to cart:', error);
            throw error;
        } finally{
            setLoading(false);
        }
    };
    // Update cart item quantity
    const updateCartItem = async (itemId, quantity)=>{
        setLoading(true);
        try {
            const data = await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cartAPI"].updateCartItem(itemId, quantity);
            if (data && data.cart && data.cart.items) {
                setCart(data.cart.items);
                calculateTotals(data.cart.items);
            } else {
                // In case the data structure is different, refresh the cart
                await refreshCart();
            }
            return data;
        } catch (error) {
            console.error('Error updating cart item:', error);
            throw error;
        } finally{
            setLoading(false);
        }
    };
    // Remove an item from the cart
    const removeFromCart = async (itemId)=>{
        setLoading(true);
        try {
            const data = await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cartAPI"].removeFromCart(itemId);
            if (data && data.cart && data.cart.items) {
                setCart(data.cart.items);
                calculateTotals(data.cart.items);
            } else {
                // In case the data structure is different, refresh the cart
                await refreshCart();
            }
            return data;
        } catch (error) {
            console.error('Error removing item from cart:', error);
            throw error;
        } finally{
            setLoading(false);
        }
    };
    // Clear the entire cart
    const clearCart = async ()=>{
        setLoading(true);
        try {
            const data = await __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$services$2f$api$2e$ts__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["cartAPI"].clearCart();
            if (data && data.cart) {
                setCart([]);
                setTotalItems(0);
                setTotalAmount(0);
            } else {
                // In case the data structure is different, refresh the cart
                await refreshCart();
            }
            return data;
        } catch (error) {
            console.error('Error clearing cart:', error);
            throw error;
        } finally{
            setLoading(false);
        }
    };
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(CartContext.Provider, {
        value: {
            cart,
            totalItems,
            totalAmount,
            loading,
            addToCart,
            updateCartItem,
            removeFromCart,
            clearCart,
            refreshCart
        },
        children: children
    }, void 0, false, {
        fileName: "[project]/app/context/CartContext.tsx",
        lineNumber: 188,
        columnNumber: 5
    }, this);
}
const useCart = ()=>{
    const context = (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["useContext"])(CartContext);
    if (context === undefined) {
        throw new Error('useCart must be used within a CartProvider');
    }
    return context;
};
}}),
"[project]/app/providers.tsx [app-ssr] (ecmascript)": ((__turbopack_context__) => {
"use strict";

var { g: global, __dirname } = __turbopack_context__;
{
__turbopack_context__.s({
    "default": (()=>Providers)
});
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/dist/server/route-modules/app-page/vendored/ssr/react-jsx-dev-runtime.js [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/context/AuthContext.tsx [app-ssr] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$app$2f$context$2f$CartContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/app/context/CartContext.tsx [app-ssr] (ecmascript)");
'use client';
;
;
;
function Providers({ children }) {
    return /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$context$2f$AuthContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["AuthProvider"], {
        children: /*#__PURE__*/ (0, __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$dist$2f$server$2f$route$2d$modules$2f$app$2d$page$2f$vendored$2f$ssr$2f$react$2d$jsx$2d$dev$2d$runtime$2e$js__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["jsxDEV"])(__TURBOPACK__imported__module__$5b$project$5d2f$app$2f$context$2f$CartContext$2e$tsx__$5b$app$2d$ssr$5d$__$28$ecmascript$29$__["CartProvider"], {
            children: children
        }, void 0, false, {
            fileName: "[project]/app/providers.tsx",
            lineNumber: 10,
            columnNumber: 7
        }, this)
    }, void 0, false, {
        fileName: "[project]/app/providers.tsx",
        lineNumber: 9,
        columnNumber: 5
    }, this);
}
}}),

};

//# sourceMappingURL=%5Broot-of-the-server%5D__a8dfedc6._.js.map