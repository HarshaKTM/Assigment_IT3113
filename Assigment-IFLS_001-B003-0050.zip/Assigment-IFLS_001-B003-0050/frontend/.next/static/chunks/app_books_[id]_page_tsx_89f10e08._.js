(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_15251bc2._.js",
  "static/chunks/app_books_[id]_page_tsx_a5a67951._.js"
],
    source: "dynamic"
});
