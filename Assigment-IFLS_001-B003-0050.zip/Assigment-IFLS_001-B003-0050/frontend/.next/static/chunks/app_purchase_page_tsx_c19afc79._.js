(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_26ef0ef7._.js",
  "static/chunks/node_modules_475a14c9._.js"
],
    source: "dynamic"
});
