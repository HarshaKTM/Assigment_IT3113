(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_e4d10f6d._.js",
  "static/chunks/node_modules_5d544214._.js"
],
    source: "dynamic"
});
