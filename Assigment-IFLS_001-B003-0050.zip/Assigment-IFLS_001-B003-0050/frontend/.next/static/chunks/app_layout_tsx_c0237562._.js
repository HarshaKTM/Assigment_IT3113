(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/[root-of-the-server]__564e7167._.css",
  "static/chunks/app_b7ddc14c._.js",
  "static/chunks/node_modules_c5177024._.js"
],
    source: "dynamic"
});
