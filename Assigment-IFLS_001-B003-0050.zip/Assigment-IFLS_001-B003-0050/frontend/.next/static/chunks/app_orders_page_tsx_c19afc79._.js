(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_9fb96900._.js",
  "static/chunks/app_orders_page_tsx_716ff245._.js"
],
    source: "dynamic"
});
