(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/node_modules_next_30e862d7._.js",
  "static/chunks/app_f9d7a34e._.js"
],
    source: "dynamic"
});
