(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_08f65403._.js",
  "static/chunks/node_modules_9fb96900._.js"
],
    source: "dynamic"
});
