(globalThis.TURBOPACK_CHUNK_LISTS = globalThis.TURBOPACK_CHUNK_LISTS || []).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/app_checkout_page_tsx_886eab41._.js",
  "static/chunks/node_modules_next_navigation_ff30cc2f.js"
],
    source: "dynamic"
});
